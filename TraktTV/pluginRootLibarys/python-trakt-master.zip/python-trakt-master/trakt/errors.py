class TraktException(Exception):
    pass
